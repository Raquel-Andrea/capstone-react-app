import "./App.css";
import Header from "./components/Header";
import SearchBar from "./components/SearchBar";
import CurrentWeather from "./components/CurrentWeather";
import Forecast from "./components/Forecast";
import NewsSection from "./components/NewsSection";

const forecastData = [
  {
    day: "Today",
    icon: "☀️",
    temperature: "22°",
    condition: "Mostly Sunny",
  },
  {
    day: "Sunday",
    icon: "🌤️",
    temperature: "23°",
    condition: "Partly Cloudy",
  },
  {
    day: "Monday",
    icon: "☀️",
    temperature: "25°",
    condition: "Sunny",
  },
  {
    day: "Tuesday",
    icon: "⛅",
    temperature: "21°",
    condition: "Cloudy",
  },
  {
    day: "Wednesday",
    icon: "🌧️",
    temperature: "19°",
    condition: "Showers",
  },
  {
    day: "Thursday",
    icon: "☀️",
    temperature: "24°",
    condition: "Sunny",
  },
  {
    day: "Friday",
    icon: "🌤️",
    temperature: "23°",
    condition: "Partly Cloudy",
  },
];

const newsData = [
  {
    image: "🌦️",
    title: "Weather patterns changing this week",
    description:
      "Meteorologists are watching changing weather conditions across the region.",
    category: "Weather",
  },
  {
    image: "⛈️",
    title: "What to know about summer storms",
    description:
      "Learn how thunderstorms develop and how to stay prepared.",
    category: "Severe Weather",
  },
  {
    image: "🌡️",
    title: "Understanding temperature changes",
    description:
      "Find out why temperatures can change quickly during the day.",
    category: "Weather Explained",
  },
];

function App() {
  return (
    <div className="app">
      <Header />

      <main>
        <SearchBar />

        <div className="quick-links">
          <a href="#weather">Today</a>
          <a href="#forecast">Hourly</a>
          <a href="#forecast">10-Day</a>
          <a href="#radar">Radar</a>
          <a href="#air-quality">Air Quality</a>
        </div>

        <CurrentWeather />

        <section className="radar-section" id="radar">
          <h2>Weather Radar</h2>
          <div className="radar-placeholder">
            <div className="radar-circle">◉</div>
            <p>Interactive weather radar</p>
            <span>Radar information would appear here</span>
          </div>
        </section>

        <div id="forecast">
          <Forecast forecast={forecastData} />
        </div>

        <NewsSection articles={newsData} />

        <section className="air-quality" id="air-quality">
          <h2>Air Quality</h2>
          <div className="air-quality-card">
            <span className="air-icon">🌿</span>
            <div>
              <strong>Good</strong>
              <p>Air quality is suitable for outdoor activities.</p>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <p>WeatherNow — Your daily weather information</p>
        <a
          href="https://www.accuweather.com/"
          target="_blank"
          rel="noreferrer"
        >
          Visit AccuWeather
        </a>
      </footer>
    </div>
  );
}

export default App;