function SearchBar() {
  return (
    <div className="search-section">
      <input
        type="text"
        placeholder="Search for a city or location"
      />
      <button>Search</button>
    </div>
  );
}

export default SearchBar;