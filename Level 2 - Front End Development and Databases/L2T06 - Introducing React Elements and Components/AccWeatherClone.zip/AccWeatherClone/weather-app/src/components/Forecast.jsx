import WeatherCard from "./WeatherCard";

function Forecast({ forecast }) {
  return (
    <section className="forecast-section">
      <h2>10-Day Forecast</h2>

      <div className="forecast-grid">
        {forecast.map((day, index) => (
          <WeatherCard
            key={index}
            day={day.day}
            icon={day.icon}
            temperature={day.temperature}
            condition={day.condition}
          />
        ))}
      </div>
    </section>
  );
}

export default Forecast;