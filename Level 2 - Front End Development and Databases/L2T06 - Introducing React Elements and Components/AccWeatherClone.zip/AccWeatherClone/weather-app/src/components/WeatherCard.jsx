function WeatherCard({ day, icon, temperature, condition }) {
  return (
    <div className="weather-card">
      <h3>{day}</h3>
      <div className="forecast-icon">{icon}</div>
      <strong>{temperature}</strong>
      <p>{condition}</p>
    </div>
  );
}

export default WeatherCard;