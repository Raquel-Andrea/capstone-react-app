function NewsSection({ articles }) {
  return (
    <section className="news-section" id="news">
      <h2>Weather News</h2>

      <div className="news-grid">
        {articles.map((article, index) => (
          <article className="news-card" key={index}>
            <div className="news-image">{article.image}</div>

            <div className="news-content">
              <h3>{article.title}</h3>
              <p>{article.description}</p>
              <span>{article.category}</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export default NewsSection;