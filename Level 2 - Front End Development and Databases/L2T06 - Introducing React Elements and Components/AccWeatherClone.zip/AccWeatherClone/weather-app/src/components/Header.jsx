function Header() {
  return (
    <header className="header">
      <div className="logo">
        WeatherNow
      </div>

      <nav>
        <a href="#weather">Weather</a>
        <a href="#radar">Radar</a>
        <a href="#news">News</a>
      </nav>
    </header>
  );
}

export default Header;