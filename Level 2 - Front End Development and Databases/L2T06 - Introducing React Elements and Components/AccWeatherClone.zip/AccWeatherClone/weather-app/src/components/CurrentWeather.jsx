function CurrentWeather() {
  return (
    <section className="current-weather" id="weather">
      <div className="location">
        <h2>Pretoria, South Africa</h2>
        <p>Today's Weather</p>
      </div>

      <div className="weather-main">
        <div className="weather-icon">☀️</div>

        <div className="temperature">
          <span>22°</span>
          <p>Mostly Sunny</p>
        </div>
      </div>

      <div className="weather-details">
        <div>
          <strong>24°</strong>
          <span>RealFeel®</span>
        </div>

        <div>
          <strong>24°</strong>
          <span>High</span>
        </div>

        <div>
          <strong>12°</strong>
          <span>Low</span>
        </div>

        <div>
          <strong>15 km/h</strong>
          <span>Wind</span>
        </div>

        <div>
          <strong>45%</strong>
          <span>Humidity</span>
        </div>
      </div>
    </section>
  );
}

export default CurrentWeather;