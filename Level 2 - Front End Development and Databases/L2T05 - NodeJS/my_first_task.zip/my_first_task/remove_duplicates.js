// Import Lodash to use its utility functions
const _ = require("lodash");

const numbers = [1, 2, 10, 100, 10, 2, 5, 6, 10, 1000, 7, 2, 100, 1, 5, 7, 10];

console.log("Original array:");
console.log(numbers);
// Remove duplicate values from the array
const uniqueNumbers = _.uniq(numbers);

console.log("Array with duplicates removed:");
console.log(uniqueNumbers);